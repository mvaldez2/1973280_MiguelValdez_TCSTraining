console.log("Jenkins and node application")
console.log("This is for the pipleline project submission")
